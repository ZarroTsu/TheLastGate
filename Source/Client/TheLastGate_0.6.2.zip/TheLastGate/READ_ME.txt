=================================================================
        ┌┬┐┌─┐┬ ┬┌─┐┌─┐┌┬┐  ┌┬┐┬ ┬┌─┐┬ ┬  ┌─┐┌─┐┌─┐┌─┐
        │││├─┤└┬┘├┤ └─┐ │    │ ├─┤│ ││ │  ├─┘├─┤└─┐└─┐
        ┴ ┴┴ ┴ ┴ └─┘└─┘ ┴    ┴ ┴ ┴└─┘└─┘  ┴  ┴ ┴└─┘└─┘
-----------------------------------------------------------------
  ________            __               __     ______      __     
 /_  __/ /_  ___     / /   ____ ______/ /_   / ____/___ _/ /____ 
  / / / __ \/ _ \   / /   / __ `/ ___/ __/  / / __/ __ `/ __/ _ \
 / / / / / /  __/  / /___/ /_/ (__  ) /_   / /_/ / /_/ / /_/  __/
/_/ /_/ /_/\___/  /_____/\__,_/____/\__/   \____/\__,_/\__/\___/ 
=================================================================
              FAQ version 0.6.0  -  by ZarroTsu
=================================================================

1. Help! My game won't run!!
2. What is The Last Gate?
3. Skill changes and additions
4. Class changes and additions

=================================================================
		- Help! My game won't run!! -
=================================================================

Mercenaries of Astonia 2, and The Last Gate, are old games with janky graphic-card specific issues and whatnot. Sometimes it's troublesome to get it working correctly. I have provided two solutions that may work separate or together from one another.

1) Delete ddraw.dll

Oddly, deleting ddraw.dll can resolve problems on certain operating systems. Perhaps the ddraw included in base MoA is defunct? Either way, try cut/pasting it to a different folder and see if it helps.


2) DxWnd

DxWnd is a program that can run older games using older draw methods. You can get DxWnd from here:

https://sourceforge.net/projects/dxwnd/

When adding The Last Gate to the list of games on its list, make sure if you specify a resolution that it is no smaller than 1280x720, or it may throw errors when the game tries to launch.


3) dgVoodoo

DgVoodoo is an alternative version to the usual DirectDraw and Direct3D .dll files, which can help get the game running on systems whose internal graphics card doesn't support the game. Simply copy all files from the folder 'fixdll' into the main directory alongside the TheLastGate.exe, overwriting the existing ddraw.dll (you may want to back up the existing ddraw.dll just in case). This solution is only recommended if you cannot get the game working by any other method, as it is known to cause the game to visually appear choppy, which may affect the quality of play.


If you have trouble with either of these solutions, please don't hesitate to ask for help on our Discord server, available through the 'Discord' button from the game's initial Options menu.

=================================================================
		- What is The Last Gate? -
=================================================================

The Last Gate is an experimental server for Mercenaries of Astonia 2. It is a playground for trying out new ideas and concepts that the traditional MoA2 server, such as Aranock, may not immediately or intentionally try, either due to fear of backlash from fans of vanilla MoA2, or due to the ideas being far too experimental or against the grain to realistically try without proof of concept.

As a general overview of the changes in The Last Gate, I will try to list as many as I can think of off the top of my head below. This FAQ will cover many of these subjects, however if it is not listed here you can ask about it either on the server (provided I am online), or on the discord (provided I don't suddenly and mysteriously cease to be).

Server changes (from vanilla) are as follows, in no particular order:

- The client has been updated to support windowed mode and a latent 1280x720 resolution.
- The message-of-the-day has been separated from the normal chat log and is now presented as its own window when loading the game.
- There is now a tutorial built into the client that can be followed or skipped at player descretion.
- The inventory is now oriented in such a way that a majority of the bag space is now visible at all times.
- Added new information that can be viewed on the HUD in the upper left.
- The "click delay" between client and server has been substantially reduced.
- The map has been rebuilt from the ground up. You will see familiar names and locations, but it will all have been redesigned and reorganized. There are many new areas to be found as well.
- There are many quests and side-quests that have been added so you don't necessarily need to grind in the pentagram quest unless you want to.
- The labyrinth extends through all 12 parts, ending at Lab 13 at around Colonel rank.
- Added over a dozen new skills and spells, including Armor Mastery, Blind, Cleave, Slow, Taunt, Weapon Mastery, and many more.
- Improved the way the game handles speed such that it increments in smaller steps, allowing speed-affecting skills and items
- Adjusted how Endurance works so it is balanced around a standard base of 100 endurance.
- Added critical hits and a critical hit multiplier as new stats that can be adjusted by some skills and items.
- Added claw weapons for the hand-to-hand skill, specializing in inflicting critical hits.
- Restorative skills such as Regenerate, Rest, and Meditate, now take effect during combat and while walking around at reduced rates.
- Players and enemies can now recover mana without needing to know the Meditate skill.
- The mana cost of spells now starts lower and grows into their standard values at 100 power, allowing early characters more lee-way with casting.
- Templar no longer rely as heavily on spells and can function well without them.
- Spells cast by players onto other players are now adjusted by a value called 'Aptitude', which limits the power of certain class combinations.
- The Heal spell now loses potency with repeated casts through a debuff called 'Healing Sickness', lasting 1 minute.
- The Dispel spell no longer affects enemy buffs in normal conditions, but can now remove up to three debuffs at a time. It now also prevents removed debuffs from being re-applied by enemies right away.
- The Stun spell has been removed and replaced by a Slow spell. Slow, as the name implies, reduces the target's speed.
- The Lockpicking skill has been removed and replaced with a simple yes/no flag. It now tells you if you're able to pick a lock by looking at the door you want to pick.
- All attributes now have their own secondary effects, such as Agility contributing to attack speed, Intuition contributing to how fast exhaustion runs out, and Willpower contributing to Aptitude.
- There are now multiple towns on the map. Players will begin their journey in the town of Lynbore, with the town of Aston acting as a second, major town.
- You can now find waypoints around the world. Using a waypoint will unlock it and allow you to travel to any waypoint you have previously visited.
- There are new armor sets dedicated to spellcasters, requiring Willpower and Intuition to equip.
- Items called Tarot Cards have been added to the game and given their own unique slot. These cards provide a variety of unique benefits to how your character behaves, sometimes at the cost of various detriments.
- Added two new arch classes, the Brawler and the Summoner.
- And many, many other changes too numerous to list.

=================================================================
		- Skill changes and additions -
=================================================================

REGENERATE
REST
MEDITATE
 - Each now produce a stronger effect.
 - Each now produce an (reduced) effect while walking or fighting.


HAND TO HAND
 - Now has its own weapon set called Claws.


DUAL WIELD *
 - New skill learned by Arch-Templar and Warriors.
 - Grants improved hit chance while using a Dual Sword in your off-hand.
 - Required for equipping higher tiers of Dual Swords.


SHIELD *
 - New skill learned by Mercenaries and Templar.
 - Grants improved parry chance while using a Shield in your off-hand.
 - Required for equipping higher tiers of Shields.


BLIND *
 - New starting skill for Mercenaries (learned by Brawlers and Summoners).
 - Applies a debuff in a circle around you, reducing enemy perception, hit, and parry.
 - Costs Endurance and unaffected by No-Magic-Zones.


CLEAVE *
 - New starting skill for Templar (learned by Warriors).
 - Strikes your foe and adjacent targets for damage based off skill score and weapon value.
 - Costs Endurance and unaffected by No-Magic-Zones.


LEAP *
 - New skill learned by Warriors.
 - Leap through the enemy in front of you, teleporting behind them in the process.
 - Cannot teleport if there is an object in the way.
 - Costs Endurance and unaffected by No-Magic-Zones.


REPAIR
 - It is now possible to repair items that have had a Soulstone used on them.


TAUNT *
 - New starting skill for Templar.
 - Taunts a target, forcing them to end combat and change targets to you.
 - Buffs the user with a defense bonus for a short duration.
 - Costs Endurance and unaffected by No-Magic-Zones.


WARCRY
 - Area of Effect is no longer effected by Warcry itself.
 - The debuff applied by Warcry now starts weaker but grows stronger with power.
 - Costs Endurance and unaffected by No-Magic-Zones.


WEAKEN *
 - New skill learned by Templar.
 - Applies a debuff to your combat target and surrounding targets, ruducing their armor and weapon values.
 - Costs Endurance and unaffected by No-Magic-Zones.


BLAST
 - Now applies a brief debuff called Scorch which increases the damage taken by the targets.


DISPEL
 - No longer affects enemy buffs, now only removes debuffs.
 - Can remove up to three debuffs at once if it can sequentially pass difficulty checks.
 - Now applies a brief buff called Immunize which prevents the removed debuffs from being re-applied.


GHOST COMPANION
 - Gains Armor and Weapon value over a gradual curve instead of in 'stages'.
 - Now learns Light, Immunity, and Surround Hit.


HASTE *
 - New spell learned by Sorcerers and Warriors.
 - Applies a self-buff that improves the caster's speed.
 - There are scrolls that can cast Haste available around the game world.


HEAL
 - Now applies a stacking debuff with consecutive use that reduces the power of the next cast of Heal.
 - This debuff lasts 1 minute, but will refresh its duration if Heal is re-cast before it expires.


IDENTIFY
 - Now displays a target character's Hit and Parry values.
 - Now displays a target item's bonus values to a broad variety of extra statistics.
 - Now displays a target item's duration if it is a consumable.


POISON *
 - New spell learned by Sorcerers.
 - Applies a debuff that deals damage over time.
 - Can be applied up to three times on the same target(s) to improve its potency.


PULSE *
 - New spell learned by Arch-Harakim.
 - Applies a self-buff to the caster which causes a burst of area damage around the caster once every few seconds.
 - The frequency of this burst can be increased with Cooldown Rate from Intuition.


RAZOR *
 - New spell learned by Brawlers.
 - Applies a self-buff to the caster which then applies a brief debuff on hit.
 - The debuff applied on hit will deal additional damage when it expires.
 - The debuff applied on hit can stack up to three times and is capable of inflicting critical hits.


SHADOW COPY *
 - New spell learned by Summoners.
 - Summons a copy of the caster for a brief duration.
 - The caster's copy will use the caster's skills as their own during their duration.
 - When the copy expires, any kill exp accumulated is awarded to the caster.


SLOW *
 - New spell learned by Harakim and Mercenaries.
 - Applies a debuff which reduces the target's action speed.
 - This debuff gradually decays over time, losing potency until the target begins to move normally again.


WEAPON MASTERY *
ARMOR MASTERY *
 - New passive skills learned by Templar.
 - Applies bonuses to Weapon Value and Armor Value respectively.


COMPANION MASTERY *
 - New passive skill learned by Summoners.
 - Grants their Ghost Companion access to the Taunt skill and Heal spell.
 - Grants additional skill maximums to the caster's Ghost Companion.


CONCENTRATE *
 - Mana cost reduction granted by Concentrate now does so at reduced power.


PRECISION *
 - New passive skill learned by Brawlers.
 - Grants a passive multiplicative bonus to critical hit rate.


PROXIMITY *
 - New passive skill learned by Arch-Harakim, Arch-Templar, Sorcerers and Warriors.
 - Grants a variety of area-of-effect bonuses to each learned class.
 - Improves Arch-Harakim AoE of Blast and Pulse.
 - Improves Arch-Templar AoE of Taunt, Warcry, and Surround hit.
 - Improves Sorcerer AoE of Curse, Poison, and Slow.
 - Improves Warrior AoE of Blind, and grants additional hit chances to Surround hit.


SWIMMING
 - Exists.

=================================================================
		- Class changes and additions -
=================================================================

TEMPLAR
 - No longer starts with Protect.
 - No longer learns Enhance.
 - Now starts with Axe, Cleave, Taunt, and Armor Mastery.
 - Now learns Weaken and Weapon Mastery.
 - Can now choose to arch as a Brawler upon reaching Lab 13.
 - Has a spell modifier of 0.60

MERCENARY
 - No longer learns Stun
 - Now starts with Blind
 - Now learns Slow and Immunity.
 - Has a spell modifier of 1.00

HARAKIM
 - No longer starts with Dispel.
 - No longer learns Stun.
 - Now learns Dispel and Slow.
 - Has a spell modifier of 1.00


ARCH-TEMPLAR
 - Starts with Dual Wield and Proximity.
 - Learns Warcry through a post-arch quest.
 - Maximum Agility is 105. Maximum Strength is 135.
 - Has a spell modifier of 0.80

BRAWLER *
 - Starts with Blind and Precision
 - Learns Razor through a post-arch quest.
 - Maximum Agility is 135. Maximum Strength is 105.
 - Has a spell modifier of 0.80

WARRIOR
 - Starts with Dual Wield, Cleave, Haste, Proximity, and Surround Hit.
 - Learns Leap through a post-arch quest.
 - Has a spell modifier of 1.05

SORCERER
 - Starts with Blast, Dispel, Haste, Concentrate, and Proximity.
 - Learns Poison through a post-arch quest.
 - Has a spell modifier of 1.05

SUMMONER *
 - Starts with Blind and Companion Mastery.
 - Learns Shadow Copy through a post-arch quest.
 - Maximum Willpower is 135. Maximum Intuition is 105.
 - Has a spell modifier of 1.10

ARCH-HARAKIM
 - Starts with Concentrate and Proximity.
 - Learns Pulse through a post-arch quest.
 - Maximum Willpower is 105. Maximum Intuition is 135.
 - Has a spell modifier of 1.10

SEYAN-DU
 - Starts with all starting skills between Templar, Mercenary, and Harakim.
 - Learns all skills that would be learned by Templar, Mercenaries, and Harakim.
 - Does not learn passive arch skills.
 - Can choose one of the following after completing the post-arch quest:
	Warcry
	Razor
	Leap
	Poison
	Shadow Copy
	Pulse
 - The difficulty to raise attributes, hitpoints and mana are reduced.
 - Has a spell modifier of 1.00

=================================================================